package com.safety.app.ui

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.safety.app.R
import com.safety.app.core.service.EmergencyForegroundService
import com.safety.app.data.PreferencesManager

class CancelAlertActivity : AppCompatActivity() {

    private lateinit var tvCountdown: TextView
    private lateinit var etPin: EditText
    private lateinit var btnConfirmCancel: Button
    private lateinit var prefs: PreferencesManager
    private var countDownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cancel_alert)

        prefs = PreferencesManager(this)
        tvCountdown = findViewById(R.id.tvCountdown)
        etPin = findViewById(R.id.etPin)
        btnConfirmCancel = findViewById(R.id.btnConfirmCancel)

        startCountdown()

        btnConfirmCancel.setOnClickListener {
            val enteredPin = etPin.text.toString().trim()
            if (enteredPin == prefs.getCancelPin()) {
                cancelEmergencyAlert()
            } else {
                Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                etPin.text.clear()
            }
        }
    }

    private fun startCountdown() {
        countDownTimer = object : CountDownTimer(10_000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = (millisUntilFinished / 1000).toInt() + 1
                tvCountdown.text = seconds.toString()
            }

            override fun onFinish() {
                tvCountdown.text = "0"
                finish() // Window expired; alert continues running
            }
        }.start()
    }

    private fun cancelEmergencyAlert() {
        countDownTimer?.cancel()
        val cancelServiceIntent = Intent(this, EmergencyForegroundService::class.java).apply {
            action = EmergencyForegroundService.ACTION_CANCEL_EMERGENCY
        }
        startService(cancelServiceIntent)
        Toast.makeText(this, "Emergency alert cancelled", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onDestroy() {
        countDownTimer?.cancel()
        super.onDestroy()
    }
}
