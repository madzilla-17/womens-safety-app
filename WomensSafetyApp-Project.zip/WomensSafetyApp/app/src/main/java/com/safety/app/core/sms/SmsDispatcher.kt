package com.safety.app.core.sms

import android.content.Context
import android.os.Build
import android.telephony.SmsManager
import com.safety.app.data.EmergencyContact

class SmsDispatcher(private val context: Context) {

    fun sendEmergencyAlert(
        contacts: List<EmergencyContact>,
        trackingUrl: String,
        isPractice: Boolean
    ): Boolean {
        val prefix = if (isPractice) "[TEST ALERT - PRACTICE MODE] " else "EMERGENCY ALERT! "
        val message = "${prefix}I need immediate help. Live tracking: $trackingUrl"

        val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(SmsManager::class.java)
        } else {
            @Suppress("DEPRECATION")
            SmsManager.getDefault()
        }

        var successCount = 0
        contacts.forEach { contact ->
            try {
                val parts = smsManager.divideMessage(message)
                smsManager.sendMultipartTextMessage(contact.phoneNumber, null, parts, null, null)
                successCount++
            } catch (e: Exception) {
                // Queued for cloud fallback
            }
        }
        return successCount > 0
    }
}
