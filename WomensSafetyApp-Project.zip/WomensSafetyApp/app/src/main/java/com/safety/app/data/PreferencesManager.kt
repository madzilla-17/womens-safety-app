package com.safety.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences = try {
        val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "safety_secure_prefs",
            masterKeyAlias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Fallback for older device emulators
        context.getSharedPreferences("safety_secure_prefs_fallback", Context.MODE_PRIVATE)
    }

    fun getCancelPin(): String {
        return prefs.getString(KEY_PIN, "1234") ?: "1234"
    }

    fun setCancelPin(pin: String) {
        prefs.edit().putString(KEY_PIN, pin).apply()
    }

    fun getContacts(): List<EmergencyContact> {
        val raw = prefs.getString(KEY_CONTACTS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(";").mapNotNull { entry ->
            val parts = entry.split(":")
            if (parts.size >= 2) EmergencyContact(parts[0], parts[1]) else null
        }
    }

    fun saveContacts(contacts: List<EmergencyContact>) {
        val serialized = contacts.joinToString(";") { "${it.name}:${it.phoneNumber}" }
        prefs.edit().putString(KEY_CONTACTS, serialized).apply()
    }

    fun isPracticeModeEnabled(): Boolean {
        return prefs.getBoolean(KEY_PRACTICE, false)
    }

    fun setPracticeMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PRACTICE, enabled).apply()
    }

    companion object {
        private const val KEY_PIN = "cancel_pin"
        private const val KEY_CONTACTS = "emergency_contacts"
        private const val KEY_PRACTICE = "practice_mode"
    }
}
