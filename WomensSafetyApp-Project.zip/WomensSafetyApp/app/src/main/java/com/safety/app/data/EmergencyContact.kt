package com.safety.app.data

data class EmergencyContact(
    val name: String,
    val phoneNumber: String,
    val priority: Int = 1
)
