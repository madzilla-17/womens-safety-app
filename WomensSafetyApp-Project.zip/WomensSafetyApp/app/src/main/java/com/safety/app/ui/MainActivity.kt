package com.safety.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.safety.app.R
import com.safety.app.core.service.EmergencyForegroundService
import com.safety.app.data.EmergencyContact
import com.safety.app.data.PreferencesManager
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: PreferencesManager
    private lateinit var tvStatus: TextView
    private lateinit var tvChecklistPermissions: TextView
    private lateinit var tvChecklistAccessibility: TextView
    private lateinit var tvChecklistContacts: TextView
    private lateinit var btnLangEn: Button
    private lateinit var btnLangHi: Button
    private lateinit var btnPractice: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PreferencesManager(this)

        tvStatus = findViewById(R.id.tvStatus)
        tvChecklistPermissions = findViewById(R.id.tvChecklistPermissions)
        tvChecklistAccessibility = findViewById(R.id.tvChecklistAccessibility)
        tvChecklistContacts = findViewById(R.id.tvChecklistContacts)
        btnLangEn = findViewById(R.id.btnLangEn)
        btnLangHi = findViewById(R.id.btnLangHi)
        btnPractice = findViewById(R.id.btnPractice)

        setupLanguageButtons()
        setupPracticeButton()
        requestAppPermissions()
        seedDefaultContactsIfEmpty()
    }

    override fun onResume() {
        super.onResume()
        updateChecklist()
    }

    private fun setupLanguageButtons() {
        btnLangEn.setOnClickListener { setAppLocale("en") }
        btnLangHi.setOnClickListener { setAppLocale("hi") }
    }

    private fun setAppLocale(languageCode: String) {
        val locale = Locale(languageCode)
        Locale.setDefault(locale)
        val config = Configuration(resources.configuration)
        config.setLocale(locale)
        @Suppress("DEPRECATION")
        resources.updateConfiguration(config, resources.displayMetrics)
        recreate()
    }

    private fun setupPracticeButton() {
        btnPractice.setOnClickListener {
            prefs.setPracticeMode(true)
            val serviceIntent = Intent(this, EmergencyForegroundService::class.java).apply {
                action = EmergencyForegroundService.ACTION_START_EMERGENCY
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            Toast.makeText(this, "Practice SOS triggered! Check SMS & notification.", Toast.LENGTH_LONG).show()
        }
    }

    private fun seedDefaultContactsIfEmpty() {
        if (prefs.getContacts().isEmpty()) {
            val sampleContacts = listOf(
                EmergencyContact("Contact 1", "+919876543210"),
                EmergencyContact("Contact 2", "+919876543211"),
                EmergencyContact("Contact 3", "+919876543212")
            )
            prefs.saveContacts(sampleContacts)
        }
    }

    private fun requestAppPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.SEND_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
        }
    }

    private fun updateChecklist() {
        val hasLoc = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val hasAudio = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val hasSms = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

        val permissionsOk = hasLoc && hasAudio && hasSms
        tvChecklistPermissions.text = if (permissionsOk) "✓ Permissions: Granted" else "✕ Permissions: Missing"
        tvChecklistPermissions.setTextColor(if (permissionsOk) 0xFF34C759.toInt() else 0xFFFF3B30.toInt())

        val accessibilityOk = isAccessibilityServiceEnabled(this)
        tvChecklistAccessibility.text = if (accessibilityOk) "✓ Trigger Service: Active" else "✕ Trigger Service: Disabled in Settings"
        tvChecklistAccessibility.setTextColor(if (accessibilityOk) 0xFF34C759.toInt() else 0xFFFF3B30.toInt())

        val contactsCount = prefs.getContacts().size
        val contactsOk = contactsCount >= 3
        tvChecklistContacts.text = if (contactsOk) "✓ 3 Contacts Saved ($contactsCount)" else "✕ 3 Contacts Saved ($contactsCount/3)"
        tvChecklistContacts.setTextColor(if (contactsOk) 0xFF34C759.toInt() else 0xFFFF3B30.toInt())

        if (permissionsOk && accessibilityOk && contactsOk) {
            tvStatus.text = getString(R.string.status_ready)
            tvStatus.setTextColor(0xFF34C759.toInt())
        } else {
            tvStatus.text = getString(R.string.status_needs_setup)
            tvStatus.setTextColor(0xFFFF9500.toInt())
        }
    }

    private fun isAccessibilityServiceEnabled(context: Context): Boolean {
        val prefString = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return prefString.contains(context.packageName)
    }
}
