package com.safety.app.core.audio

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import java.io.File

class AudioRecorderManager(private val context: Context) {

    private var mediaRecorder: MediaRecorder? = null
    private var isRecording = false

    fun startRecording(sessionId: String): File? {
        if (isRecording) return null

        val dir = File(context.filesDir, "audio_evidence").apply { mkdirs() }
        val outputFile = File(dir, "sos_${sessionId}_${System.currentTimeMillis()}.m4a")

        return try {
            mediaRecorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(64000)
                setAudioSamplingRate(22050)
                setOutputFile(outputFile.absolutePath)
                prepare()
                start()
            }
            isRecording = true
            outputFile
        } catch (e: Exception) {
            null
        }
    }

    fun stopRecording() {
        if (!isRecording) return
        try {
            mediaRecorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            // Ignore stop errors if recording was too short
        } finally {
            mediaRecorder = null
            isRecording = false
        }
    }
}
