package com.safety.app.core.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.safety.app.core.audio.AudioRecorderManager
import com.safety.app.core.sms.SmsDispatcher
import com.safety.app.data.PreferencesManager
import com.safety.app.ui.CancelAlertActivity
import java.util.UUID

class EmergencyForegroundService : Service() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var preferencesManager: PreferencesManager
    private lateinit var audioRecorderManager: AudioRecorderManager
    private lateinit var smsDispatcher: SmsDispatcher

    private var currentSessionId: String = ""
    private var isTracking = false

    companion object {
        const val ACTION_START_EMERGENCY = "com.safety.app.START_EMERGENCY"
        const val ACTION_CANCEL_EMERGENCY = "com.safety.app.CANCEL_EMERGENCY"
        private const val CHANNEL_ID = "emergency_service_channel"
        private const val NOTIFICATION_ID = 9110
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        preferencesManager = PreferencesManager(this)
        audioRecorderManager = AudioRecorderManager(this)
        smsDispatcher = SmsDispatcher(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_EMERGENCY -> {
                if (!isTracking) {
                    startEmergencyPipeline()
                }
            }
            ACTION_CANCEL_EMERGENCY -> {
                stopEmergencyPipeline()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun startEmergencyPipeline() {
        isTracking = true
        currentSessionId = UUID.randomUUID().toString()

        val notification = buildOngoingNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
            }
            startForeground(NOTIFICATION_ID, notification, serviceType)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // 1. Initial quick location & SMS dispatch
        fetchInitialLocationAndSendSms()

        // 2. Start continuous GPS tracking
        startContinuousLocationTracking()

        // 3. Start local audio capture
        audioRecorderManager.startRecording(currentSessionId)
    }

    private fun fetchInitialLocationAndSendSms() {
        val isPractice = preferencesManager.isPracticeModeEnabled()
        val contacts = preferencesManager.getContacts()

        try {
            fusedLocationClient.lastLocation.addOnSuccessListener { loc ->
                val trackingUrl = if (loc != null) {
                    "https://safety.app/live/$currentSessionId?lat=${loc.latitude}&lng=${loc.longitude}"
                } else {
                    "https://safety.app/live/$currentSessionId"
                }
                smsDispatcher.sendEmergencyAlert(contacts, trackingUrl, isPractice)
            }.addOnFailureListener {
                smsDispatcher.sendEmergencyAlert(
                    contacts,
                    "https://safety.app/live/$currentSessionId",
                    isPractice
                )
            }
        } catch (e: SecurityException) {
            smsDispatcher.sendEmergencyAlert(
                contacts,
                "https://safety.app/live/$currentSessionId",
                isPractice
            )
        }
    }

    private fun startContinuousLocationTracking() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10_000L)
            .setMinUpdateIntervalMillis(5_000L)
            .setMinUpdateDistanceMeters(5.0f)
            .build()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                val location = result.lastLocation ?: return
                // Process and stream live coordinate update
            }
        }

        try {
            fusedLocationClient.requestLocationUpdates(request, locationCallback, mainLooper)
        } catch (_: SecurityException) {}
    }

    private fun stopEmergencyPipeline() {
        if (!isTracking) return
        isTracking = false
        try {
            fusedLocationClient.removeLocationUpdates(locationCallback)
        } catch (_: Exception) {}
        audioRecorderManager.stopRecording()
    }

    private fun buildOngoingNotification(): Notification {
        val cancelIntent = Intent(this, CancelAlertActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            cancelIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Emergency Alert Active")
            .setContentText("Transmitting location & capturing audio evidence.")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Emergency Active Service",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Emergency tracking and evidence recording"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopEmergencyPipeline()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
