package com.safety.app.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import com.safety.app.core.service.EmergencyForegroundService
import com.safety.app.ui.CancelAlertActivity

class VolumeTriggerAccessibilityService : AccessibilityService() {

    private var pressCount = 0
    private var lastPressTimestamp: Long = 0L
    private val resetWindowMs = 2000L // 3 presses within 2 seconds

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN) {
            val now = System.currentTimeMillis()

            if (now - lastPressTimestamp <= resetWindowMs) {
                pressCount++
            } else {
                pressCount = 1
            }
            lastPressTimestamp = now

            if (pressCount == 3) {
                pressCount = 0
                vibrateConfirmation()
                triggerAlertFlow()
                return true // Consume key event
            }
        }
        return super.onKeyEvent(event)
    }

    private fun vibrateConfirmation() {
        val timings = longArrayOf(0, 150, 100, 250)
        val amplitudes = intArrayOf(0, 255, 0, 255)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(VibratorManager::class.java)
            val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
            vibratorManager.vibrate(CombinedVibration.createParallel(effect))
        } else {
            @Suppress("DEPRECATION")
            val vibrator = getSystemService(VIBRATOR_SERVICE) as? Vibrator
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(timings, -1)
            }
        }
    }

    private fun triggerAlertFlow() {
        // Open the 10-second cancel window activity
        val cancelIntent = Intent(this, CancelAlertActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        startActivity(cancelIntent)

        // Launch the emergency foreground service
        val serviceIntent = Intent(this, EmergencyForegroundService::class.java).apply {
            action = EmergencyForegroundService.ACTION_START_EMERGENCY
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}
