# Women's Safety App (Android MVP)

## 📌 Project Overview
A production-ready Android MVP designed to let a woman trigger an emergency SOS alert in seconds, one-handed, with the screen locked or off.

---

## 🚀 Quick Start / How to Build the APK

### Prerequisites
- **Android Studio Jellyfish | 2024.1.1+** or **Koala**
- **Android SDK Platform 34** (Upside Down Cake)
- **JDK 17**

### Building via Android Studio:
1. Open Android Studio.
2. Select **File > Open...** and navigate to this folder (`WomensSafetyApp`).
3. Allow Gradle to sync dependencies.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be generated at:
   `app/build/outputs/apk/debug/app-debug.apk`.

### Building via Terminal / Command Line:
```bash
cd WomensSafetyApp
./gradlew assembleDebug
```
The resulting APK:
```text
app/build/outputs/apk/debug/app-debug.apk
```

---

## 📲 How to Install & Test on a Physical Phone

1. **Install APK**:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

2. **Grant Permissions**:
   Open the app once or run:
   ```bash
   adb shell pm grant com.safety.app android.permission.ACCESS_FINE_LOCATION
   adb shell pm grant com.safety.app android.permission.RECORD_AUDIO
   adb shell pm grant com.safety.app android.permission.SEND_SMS
   ```

3. **Enable Accessibility Trigger**:
   - Go to **Settings > Accessibility > Downloaded Apps > Raksha SOS**.
   - Turn the toggle **ON**.
   - *(Note: On Android 13+, if "Restricted setting" is shown, go to App Info > 3 dots > "Allow restricted settings", then enable Accessibility).*

4. **Battery Unrestricted Mode**:
   - App Info > Battery > Select **Unrestricted**.

5. **Test Trigger**:
   - Turn your phone's screen **OFF**.
   - Rapidly press **Volume Down 3 times** within 2 seconds.
   - You will feel a confirmation vibration, see the 10-second PIN cancel screen, start background audio recording, and dispatch emergency SMS with live GPS coordinates.
